package com.example.demo.service;

import static org.junit.jupiter.api.Assertions.*;

class UserServiceTest {

}