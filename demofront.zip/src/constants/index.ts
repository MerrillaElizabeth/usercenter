
export const SYSTEM_LOGO = "https://himg.bdimg.com/sys/portraitn/item/public.1.e137c1ac.yS1WqOXfSWEasOYJ2-0pvQ";

export const AUTHOE_Bilibili ="https://space.bilibili.com/1427029765";


export const selectGender = [
  { value: 0, label: '男' },
  { value: 1, label: '女' },
];
export const selectUserStatus = [
  { value: 0, label: '正常' },
  { value: 1, label: '注销' },
];
export const selectUserRole = [
  { value: 0, label: '普通用户' },
  { value: 1, label: '管理员' },
];
